Imports System

Module Program
    Sub Main(args As String())

        'vari�veis
        Dim n As Integer
        n = 0

        Do
            n = n + 1
            If n Mod 3 <> 0 And n Mod 5 <> 0 Then
                Console.WriteLine(n & " ")
            Else
                If n Mod 3 = 0 And n Mod 5 <> 0 Then
                    Console.WriteLine("Fizz ")
                Else
                    If n Mod 3 <> 0 And n Mod 5 = 0 Then
                        Console.WriteLine("Buzz ")
                    Else
                        Console.WriteLine("FizzBuzz ")
                    End If
                End If
            End If



        Loop Until n = 36



    End Sub
End Module
